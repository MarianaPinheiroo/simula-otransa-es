// Variáveis globais
let currentPin = '';
let purchaseValue = 0;
const correctPin = '1234'; // Senha padrão para demonstração

// Atualiza a visualização do cartão conforme os campos são preenchidos
function updateCardPreview() {
    const cardName = document.getElementById('card-name').value || 'NOME NO CARTÃO';
    const cardExpiry = document.getElementById('card-expiry').value || 'MM/AAAA';
    const cardType = document.getElementById('card-type').value;
    const cardNumber = document.getElementById('card-number').value;
    
    document.getElementById('preview-card-name').textContent = cardName.toUpperCase();
    document.getElementById('preview-card-expiry').textContent = cardExpiry;
    document.getElementById('preview-card-type').textContent = cardType;
    
    // Atualiza o logo do cartão
    let logoUrl = '';
    if (cardType === 'VISA') {
        logoUrl = 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/2560px-Visa_Inc._logo.svg.png';
    } else if (cardType === 'MASTERCARD') {
        logoUrl = 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Mastercard-logo.svg/1280px-Mastercard-logo.svg.png';
    } else if (cardType === 'AMEX') {
        logoUrl = 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/American_Express_logo.svg/1200px-American_Express_logo.svg.png';
    }
    document.getElementById('preview-card-logo').src = logoUrl;
    
    // Atualiza o número do cartão no preview
    if (cardNumber) {
        document.querySelector('.card-number').textContent = formatCardNumberForDisplay(cardNumber);
    } else {
        document.querySelector('.card-number').textContent = '•••• •••• •••• ••••';
    }
}

// Formata o número do cartão para exibição (substitui por •)
function formatCardNumberForDisplay(cardNumber) {
    const cleaned = cardNumber.replace(/\s+/g, '');
    let formatted = '';
    
    for (let i = 0; i < cleaned.length; i++) {
        if (i > 0 && i % 4 === 0) {
            formatted += ' ';
        }
        formatted += i < cleaned.length - 4 ? '•' : cleaned[i];
    }
    
    return formatted;
}

// Formata o número do cartão com espaços
function formatCardNumber(input) {
    let value = input.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    let formatted = '';
    
    for (let i = 0; i < value.length; i++) {
        if (i > 0 && i % 4 === 0) {
            formatted += ' ';
        }
        formatted += value[i];
    }
    
    input.value = formatted;
    updateCardPreview();
}

// Formata a data de validade
function formatExpiry(input) {
    let value = input.value.replace(/[^0-9]/g, '');
    
    if (value.length > 2) {
        value = value.substring(0, 2) + '/' + value.substring(2, 6);
    }
    
    input.value = value;
    updateCardPreview();
}

// Adiciona um dígito ao PIN
function addPinDigit(digit) {
    if (currentPin.length < 4) {
        currentPin += digit;
        updatePinDisplay();
    }
}

// Remove o último dígito do PIN
function clearPinDigit() {
    currentPin = currentPin.slice(0, -1);
    updatePinDisplay();
}

// Atualiza a exibição do PIN
function updatePinDisplay() {
    let display = '';
    for (let i = 0; i < 4; i++) {
        display += i < currentPin.length ? '•' : '';
    }
    document.getElementById('pin-display').textContent = display;
}

// Envia o PIN para validação
function submitPin() {
    if (currentPin.length < 4) {
        alert('Por favor, insira os 4 dígitos da senha');
        return;
    }
    
    // Simula processamento
    setTimeout(() => {
        if (currentPin === correctPin) {
            showPage('success-page');
            // Volta para a página inicial após 3 segundos
            setTimeout(() => {
                showPage('card-page');
                resetForms();
            }, 3000);
        } else {
            showPage('error-page');
        }
        currentPin = '';
    }, 500);
}

// Mostra uma página específica
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById(pageId).classList.add('active');
}

// Reseta todos os formulários
function resetForms() {
    document.getElementById('card-name').value = '';
    document.getElementById('card-number').value = '';
    document.getElementById('card-expiry').value = '';
    document.getElementById('card-cvv').value = '';
    document.getElementById('card-type').value = 'VISA';
    document.getElementById('purchase-value').value = '';
    currentPin = '';
    updateCardPreview();
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Atualiza o preview do cartão quando os campos mudam
    document.getElementById('card-name').addEventListener('input', updateCardPreview);
    document.getElementById('card-number').addEventListener('input', function() {
        formatCardNumber(this);
    });
    document.getElementById('card-expiry').addEventListener('input', function() {
        formatExpiry(this);
    });
    document.getElementById('card-type').addEventListener('change', updateCardPreview);
    
    // Configura os botões do teclado numérico
    document.querySelectorAll('.key[data-digit]').forEach(key => {
        key.addEventListener('click', function() {
            addPinDigit(this.getAttribute('data-digit'));
        });
    });
    
    document.getElementById('clear-key').addEventListener('click', clearPinDigit);
    document.getElementById('submit-key').addEventListener('click', submitPin);
    
    // Botão de confirmar valor
    document.getElementById('confirm-btn').addEventListener('click', function() {
        // Validação básica dos campos
        const cardName = document.getElementById('card-name').value;
        const cardNumber = document.getElementById('card-number').value.replace(/\s/g, '');
        const cardExpiry = document.getElementById('card-expiry').value;
        const cardCvv = document.getElementById('card-cvv').value;
        purchaseValue = parseFloat(document.getElementById('purchase-value').value);
        
        if (!cardName || !cardNumber || !cardExpiry || !cardCvv || !purchaseValue || isNaN(purchaseValue)) {
            alert('Por favor, preencha todos os campos corretamente');
            return;
        }
        
        if (cardNumber.length < 16) {
            alert('Por favor, insira um número de cartão válido');
            return;
        }
        
        if (cardCvv.length < 3) {
            alert('Por favor, insira um CVV válido');
            return;
        }
        
        // Mostra a página da maquininha
        showPage('terminal-page');
        document.getElementById('purchase-amount-display').textContent = 
            'R$ ' + purchaseValue.toFixed(2).replace('.', ',');
    });
    
    // Botão de tentar novamente
    document.getElementById('try-again-btn').addEventListener('click', function() {
        showPage('terminal-page');
        currentPin = '';
        updatePinDisplay();
    });
    
    // Botão de voltar ao início
    document.getElementById('back-to-start-btn').addEventListener('click', function() {
        showPage('card-page');
        resetForms();
    });
    
    // Inicializa o preview do cartão
    updateCardPreview();
});